#!/user/bin/env python
# -*- coding:utf-8 -*-
# @Author:  blueSky
# @Time: 2019年04月24日20时24分05秒

x=3
x+=3
print(x)
x-=3
print(x)
x*=3
print(x)
x/=3
print(x)

