#!/user/bin/env python
# -*- coding:utf-8 -*-
# @Author:  blueSky
# @Time: 2019年04月24日20时28分30秒
#
# # 赋值语句
# a=10;
# print(a)

# # 简单条件分支语句
# a=20;
# if(a>10):
#     print("我是二百五");
# else:
#     print("我不是二百五");

# 复杂点的条件分支语句

# a=20;
# if(a>20):
#     print("胡")
# elif(10<a<20):
#     print("庐")
# else:
#     print("林")

# #嵌套条件循环
# num=int(input("请输入一个数字："))
# if num%2==0:
#     if num%3==0:
#         print("你输入的数可以整除2和3")
#     else:
#         print("你输入的数只能整除2不能整除3")
# else:
#     if num%3==0:
#         print("你输入的数可以整除3但不能整除2")
#     else:
#         print("你输入的数不能整除2也不能整除3")

# # whlie循环语句
# n=100;
# sum=0;
# counter=1;
# while counter<=n:
#     sum+=counter;
#     counter+=1;
# print("1到%d之和为:%d" %(n,sum))

# # 死循环（无限循环）
# var=1;
# while var==1:
#     num=int(input("请输入一个数："))
#     print("你输入的数为："+num)
# print("Good Bye!")
#
# # for 语句
# """
# for <variable> in <sequence>:
#     <statements>
# else:
#     <statements>
# """
# language=["C","C++","python","java"];
# for x in  language:
#     print(x);

