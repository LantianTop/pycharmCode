#!/user/bin/env python
# -*- coding:utf-8 -*-
# @Author:  blueSky
# @Time: 2019年04月25日07时21分42秒

print("%d %d %d" %(1,2,3))
print("%d %d %d" %(1.1,1.3,3.6))

print("%e %e %e"%(1.1,2.5,3.6))
print("%f %f %f"%(1.1,2.5,3.6))
print("%5.2f %5.3f %6.7f"%(1.1,2.5,3.6))
print("%10.2f %5.3f %6.7f"%(12345.12345,2.5,3.6))